package com.geyikgames.TweetFetcher;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TweetFetcherApplicationTests {

	@Test
	void contextLoads() {
	}

}
