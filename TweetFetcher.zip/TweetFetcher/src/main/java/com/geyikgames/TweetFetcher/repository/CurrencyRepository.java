package com.geyikgames.TweetFetcher.repository;

import com.geyikgames.TweetFetcher.model.Currency;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

@Repository
public interface CurrencyRepository extends JpaRepository<Currency, String> {
    @Query(value = "SELECT * FROM currency where created_at >= ?1 and created_at <= ?2 AND extract('ISODOW' FROM created_at) < 6",nativeQuery = true)
    List<Currency> findAllByMinutely(Date startDate, Date endDate);

    @Query(value = "SELECT * FROM currency where created_at >= ?1 and created_at <= ?2 and to_char(\"created_at\", 'MI') = '00' AND extract('ISODOW' FROM created_at) < 6",nativeQuery = true)
    List<Currency> findAllByHourly(Date startDate, Date endDate);
}
