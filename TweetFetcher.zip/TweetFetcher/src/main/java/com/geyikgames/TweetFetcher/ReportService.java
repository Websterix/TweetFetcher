package com.geyikgames.TweetFetcher;

import com.geyikgames.TweetFetcher.model.Currency;
import com.geyikgames.TweetFetcher.model.Stock;
import com.geyikgames.TweetFetcher.model.Tweet;
import com.geyikgames.TweetFetcher.repository.CurrencyRepository;
import com.geyikgames.TweetFetcher.repository.StockRepository;
import com.geyikgames.TweetFetcher.repository.TweetRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import static java.util.stream.Collectors.groupingBy;

@Component
@RequiredArgsConstructor
public class ReportService {
    private final CurrencyRepository currencyRepository;
    private final StockRepository stockRepository;
    private final TweetRepository tweetRepository;

//    @PostConstruct
    public Map<Date,List<Currency>> reportMinutely(Date startDate, Date endDate) throws ParseException {
        Map<Date,List<Currency>> currencies = currencyRepository.findAllByMinutely(startDate,endDate).stream().collect(groupingBy(Currency::getCreatedAt));
        Map<Date, List<Stock>> stocks = stockRepository.findAllByMinutely(startDate,endDate).stream().collect(groupingBy(Stock::getCreatedAt));
        Map<Date, List<Tweet>> tweets = tweetRepository.findAllByMinutely(startDate,endDate).stream().collect(groupingBy(Tweet::getCreatedAt));
        return null;
    }

    public void reportHourly(Date startDate, Date endDate){
        List<Currency> result = currencyRepository.findAllByHourly(startDate,endDate);
//        return result.stream().collect(groupingBy(Currency::getCreatedAt));
    }

    public void reportDaily(){

    }
}
