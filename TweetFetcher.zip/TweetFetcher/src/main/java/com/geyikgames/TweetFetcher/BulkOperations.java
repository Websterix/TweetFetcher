package com.geyikgames.TweetFetcher;

import com.geyikgames.TweetFetcher.model.Currency;
import com.geyikgames.TweetFetcher.model.Stock;
import com.geyikgames.TweetFetcher.model.Tweet;
import com.geyikgames.TweetFetcher.repository.CurrencyRepository;
import com.geyikgames.TweetFetcher.repository.StockRepository;
import com.geyikgames.TweetFetcher.repository.TweetRepository;
import com.google.common.base.Splitter;
import com.google.common.collect.Iterables;
import org.apache.log4j.LogManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;


@Component
public class BulkOperations {
    public static final String SPLITERATOR = "MySpl!ter@tor";
    public static org.apache.log4j.Logger log = LogManager.getLogger(BulkOperations.class);
    private static SimpleDateFormat formatter = new SimpleDateFormat("dd.M.yyyy HH:mm:ss");

    private final TweetRepository tweetRepository;
    private final StockRepository stockRepository;
    private final CurrencyRepository currencyRepository;

    @Autowired
    public BulkOperations(TweetRepository tweetRepository, StockRepository stockRepository, CurrencyRepository currencyRepository) {
        this.tweetRepository = tweetRepository;
        this.stockRepository = stockRepository;
        this.currencyRepository = currencyRepository;

        try {
            insertTweets("D:\\Backup\\TweetsBackup\\PlainTweets");
            insertStocks("D:\\Backup\\TweetsBackup\\StockValues\\");
            insertCurrencies("D:\\Backup\\TweetsBackup\\CurrencyValues\\");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void insertTweets(String tweetsFolderPath) throws Exception {
        List<Path> files = Collections.synchronizedList(new ArrayList<>());
        List<Path> folderPaths = Files.walk(Paths.get(tweetsFolderPath), 1).collect(Collectors.toList());
        for (Path folder : folderPaths) {
            List<Path> filePaths = Files.walk(folder, 1).filter(Files::isRegularFile).collect(Collectors.toList());
            int totalFileCount = filePaths.size();
            for (int i = 0; i < totalFileCount; i++) {
                Path file = filePaths.get(i);
                files.add(file);
            }
        }


        System.out.println("Files: " + files.size());
        for (Path file : files) {
            insertTweetsFromFile(file);
        }
    }


    public void insertCurrencies(String currenciesFolderPath) throws Exception {
        List<Path> filePaths = Files.walk(Paths.get(currenciesFolderPath), 1).filter(Files::isRegularFile).collect(Collectors.toList());
        System.out.println("Files: " + filePaths.size());
        for (Path file : filePaths) {
            insertCurrenciesFromFile(file);
        }
    }

    public void insertStocks(String stocksFolderPath) throws Exception {
        List<Path> filePaths = Files.walk(Paths.get(stocksFolderPath), 1).filter(Files::isRegularFile).collect(Collectors.toList());
        System.out.println("Files: " + filePaths.size());
        for (Path file : filePaths) {
            insertStocksFromFile(file);
        }
    }

    private void insertStocksFromFile(Path file) {
        try {
            long count = 0;
            List<String> lines = Files.readAllLines(file);
            lines.remove(0); // Remove Header
            for (String line : lines) {
                String[] components = line.split(",");
                Stock stock = new Stock();
                stock.setName(file.getFileName().toString().substring(5).replace(".csv", ""));
                stock.setValue(Double.parseDouble(components[components.length - 2]));
                String[] dateTime = components[0].split(" ");
                String createdAt = dateTime[0] + " " + dateTime[1];
                stock.setCreatedAt(formatter.parse(createdAt));
                try {
                    stockRepository.save(stock);
                } catch (Throwable t) {
                    // Ignore
                }
                count++;
                if ((count % 10000 == 0) || (count == lines.size())) {
                    System.out.println("Inserted(" + file.getFileName().toString() + ") " + count + "/" + lines.size());
                }
            }
            System.out.println("Stocks Inserted to DB");
            Files.move(file, Paths.get("D:\\Backup\\TweetsBackup\\DbMigrated\\" + file.getFileName()));
        } catch (Exception e) {

        }
    }

    private void insertCurrenciesFromFile(Path file) {
        try {
            long count = 0;
            List<String> lines = Files.readAllLines(file);

            lines.remove(0); // Remove Header
            for (String line : lines) {
                String[] components = line.split(",");
                Currency currency = new Currency();
                currency.setParity(file.getFileName().toString().replace(".csv", ""));
                currency.setValue(Double.parseDouble(components[components.length - 2]));
                String[] dateTime = components[0].split(" ");
                String createdAt = dateTime[0] + " " + dateTime[1];
                currency.setCreatedAt(formatter.parse(createdAt));
                try {
                    currencyRepository.save(currency);
                } catch (Throwable t) {
                    // Ignore
                }
                count++;
                if ((count % 10000 == 0) || (count == lines.size())) {
                    System.out.println("Inserted(" + file.getFileName().toString() + ") " + count + "/" + lines.size());
                }
            }
            System.out.println("Stocks Inserted to DB");
            Files.move(file, Paths.get("D:\\Backup\\TweetsBackup\\DbMigrated\\" + file.getFileName()));
        } catch (Exception e) {

        }
    }

    private void insertTweetsFromFile(Path file) {
        try {
            Splitter splitter = Splitter.on(SPLITERATOR);
            List<String> lines = Files.readAllLines(file);
            int count = 0;

            lines.remove(0); // Remove Header
            for (String line : lines) {
                String[] components = Iterables.toArray(splitter.split(line), String.class);
                if (components.length != 9) {
                    log.error("Error occurred. Skipping Problematic Tweet.");
                    continue;
                }

                Tweet tweet = new Tweet();
                tweet.setId(Long.parseUnsignedLong(components[0]));
                SimpleDateFormat formatter = new SimpleDateFormat("yyyy-M-dd HH:mm:ss");
                Date createdAt = formatter.parse(components[1]);
                tweet.setCreatedAt(createdAt);
                tweet.setHashTag(components[2]);
                tweet.setText(components[3]);
                tweet.setSentiment(Double.parseDouble(components[7]));
                try {
                    tweetRepository.save(tweet);
                } catch (Throwable t) {
                    // Ignore
                }
                count++;
                if ((count % 5000 == 0) || (count == lines.size())) {
                    System.out.println("Inserted(" + file.getFileName().toString() + ") " + count + "/" + lines.size());
                }
            }
            System.out.println("Tweets Inserted to DB");
            Files.move(file, Paths.get("D:\\Backup\\TweetsBackup\\DbMigrated\\" + file.getFileName()));

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}