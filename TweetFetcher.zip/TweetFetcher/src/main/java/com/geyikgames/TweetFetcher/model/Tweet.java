package com.geyikgames.TweetFetcher.model;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name= "TWEET")
@Getter
@Setter
public class Tweet {
    @Id
    private long id;
    private Date createdAt;
    private String hashTag;
    @Column(length = 1000)
    private String text;
    private double sentiment;
}
