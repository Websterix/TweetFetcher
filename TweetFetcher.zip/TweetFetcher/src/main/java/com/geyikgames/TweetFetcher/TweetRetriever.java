package com.geyikgames.TweetFetcher;


import org.apache.log4j.LogManager;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

@Component
public class TweetRetriever {

    final int FIVE_MINUTES_IN_MS = 300000;
    HashMap<String, Boolean> hashtags = new HashMap<>();
    public static org.apache.log4j.Logger log = LogManager.getLogger(TweetRetriever.class);

    public TweetRetriever() {
        String[] tags = {"#forex", "#usdtry", "#dolar", "#dollar", "#euro", "#economy",
                "#trump", "#obama", "#donaldtrump", "#breakingnews", "#breaking", "#today", "#day", "#currency",
                "#money", "#exchange", "#investing", "#stockmarket", "#stocks", "#stock", "#market", "#trading",
                "#usa", "#turkey"};

        Arrays.stream(tags).forEach(tag -> hashtags.put(tag, false));
    }

    @Scheduled(fixedRate = FIVE_MINUTES_IN_MS)
    public void retrieveTweets() throws InterruptedException {
//        log.info("Retrieving Tweets for Hashtags.");
//
//        while (hashtags.values().stream().anyMatch(x -> !x)) {
//            hashtags.forEach((hashtag, isProcessed) -> {
//                if (!isProcessed) {
//                    hashtags.replace(hashtag, retrieveHashtag(hashtag));
//                }
//            });
//        }
    }

    private boolean retrieveHashtag(String hashTag) {
        try {
            log.error("Retrieving Hashtag: " + hashTag);
            return true;
        } catch (Exception ex) {
            log.error("Exception Occurred",ex);
            return false;
        }
    }
}